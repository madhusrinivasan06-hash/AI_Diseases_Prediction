from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from pathlib import Path
import joblib
import numpy as np

from . import db
from .models import User, Prediction

main = Blueprint("main", __name__)

BASE = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE / "model" / "disease_model.joblib"

def get_artifact():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

def current_user():
    uid = session.get("user_id")
    return User.query.get(uid) if uid else None

@main.context_processor
def inject_user():
    return {"current_user": current_user()}

@main.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("main.dashboard"))
    return render_template("landing.html")

@main.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or len(password) < 6:
            flash("Enter all details. Password must be at least 6 characters.", "danger")
            return redirect(url_for("main.register"))

        if User.query.filter_by(email=email).first():
            flash("An account with this email already exists.", "warning")
            return redirect(url_for("main.login"))

        user = User(
            name=name,
            email=email,
            password_hash=generate_password_hash(password)
        )
        db.session.add(user)
        db.session.commit()
        session["user_id"] = user.id
        return redirect(url_for("main.dashboard"))

    return render_template("auth.html", mode="register")

@main.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid email or password.", "danger")
            return redirect(url_for("main.login"))

        session["user_id"] = user.id
        return redirect(url_for("main.dashboard"))

    return render_template("auth.html", mode="login")

@main.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("main.index"))

@main.route("/dashboard")
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for("main.login"))

    recent = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.desc()).limit(5).all()
    total = Prediction.query.filter_by(user_id=user.id).count()
    unique = len({p.predicted_disease for p in user.predictions})
    return render_template("dashboard.html", recent=recent, total=total, unique=unique)

@main.route("/predictor")
def predictor():
    if not current_user():
        return redirect(url_for("main.login"))
    artifact = get_artifact()
    if not artifact:
        flash("Model not found. Run: python train_model.py", "danger")
        return redirect(url_for("main.dashboard"))
    return render_template("predictor.html", symptoms=artifact["features"])

@main.route("/predict", methods=["POST"])
def predict():
    user = current_user()
    if not user:
        return jsonify({"error": "Please login first."}), 401

    artifact = get_artifact()
    if not artifact:
        return jsonify({"error": "Model not found. Run train_model.py first."}), 500

    selected = request.get_json(silent=True) or {}
    selected_symptoms = selected.get("symptoms", [])

    features = artifact["features"]
    x = np.array([[1 if s in selected_symptoms else 0 for s in features]])

    model = artifact["model"]
    encoder = artifact["label_encoder"]

    pred = model.predict(x)[0]
    disease = encoder.inverse_transform([pred])[0]

    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(x)[0]
        confidence = float(np.max(probs))
        top_idx = np.argsort(probs)[::-1][:3]
        alternatives = [
            {"disease": str(encoder.inverse_transform([i])[0]), "confidence": float(probs[i])}
            for i in top_idx
        ]
    else:
        confidence = 0.0
        alternatives = [{"disease": disease, "confidence": 0.0}]

    record = Prediction(
        user_id=user.id,
        symptoms=", ".join(selected_symptoms),
        predicted_disease=disease,
        confidence=confidence
    )
    db.session.add(record)
    db.session.commit()

    return jsonify({
        "disease": disease,
        "confidence": confidence,
        "alternatives": alternatives,
        "record_id": record.id
    })

@main.route("/history")
def history():
    user = current_user()
    if not user:
        return redirect(url_for("main.login"))
    predictions = Prediction.query.filter_by(user_id=user.id).order_by(Prediction.created_at.desc()).all()
    return render_template("history.html", predictions=predictions)

@main.route("/about")
def about():
    return render_template("about.html")
