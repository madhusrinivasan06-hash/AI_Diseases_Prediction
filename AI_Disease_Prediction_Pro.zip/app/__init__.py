from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from pathlib import Path

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    base = Path(__file__).resolve().parent.parent
    app.config["SECRET_KEY"] = "change-this-secret-key-for-production"
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{base / 'instance' / 'disease_app.db'}"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    from .routes import main
    app.register_blueprint(main)

    with app.app_context():
        db.create_all()

    return app
