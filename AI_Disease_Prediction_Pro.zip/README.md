# AI Disease Prediction System — Advanced Student Project

A modern Flask + SQLite + scikit-learn web application for educational demonstration.

## Features
- User registration/login/logout
- Secure password hashing
- Symptom selection/search
- ML disease prediction using a Decision Tree
- Confidence score and top prediction alternatives
- Prediction history stored per user
- Dashboard with statistics
- Responsive modern UI
- SQLite database
- Automatic model training from the included dataset
- Educational safety disclaimer

## Important
This is an academic demonstration project, not a medical diagnostic device.
Predictions must not be used to diagnose, treat, or rule out real medical conditions.

## Run on Windows
1. Install Python 3.11+.
2. Open this folder in VS Code.
3. Open Terminal.
4. Create a virtual environment:
   python -m venv venv
5. Activate it:
   venv\Scripts\activate
6. Install packages:
   pip install -r requirements.txt
7. Train the model:
   python train_model.py
8. Start the application:
   python run.py
9. Open:
   http://127.0.0.1:5000

Demo account is NOT pre-created. Register your own account from the Sign Up page.

## Screenshots for evaluation
Capture:
1. Registration/Login
2. Dashboard
3. Symptom selection
4. Prediction result
5. Prediction history
6. About/model information

## Model
The included educational dataset contains symptom combinations and disease labels.
The application uses a Decision Tree classifier with binary symptom features.
The model file is generated locally by train_model.py.

## Project structure
app/
  __init__.py
  models.py
  routes.py
  templates/
  static/
data/
  symptoms_dataset.csv
model/
  disease_model.joblib
instance/
run.py
train_model.py
requirements.txt
README.md
