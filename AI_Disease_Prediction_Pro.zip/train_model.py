from pathlib import Path
import pandas as pd
import joblib
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "symptoms_dataset.csv"
MODEL_DIR = BASE / "model"
MODEL_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
feature_cols = [c for c in df.columns if c != "disease"]

X = df[feature_cols].astype(int)
y = df["disease"]

encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

model = DecisionTreeClassifier(
    random_state=42,
    max_depth=8,
    min_samples_leaf=1
)
model.fit(X_train, y_train)

accuracy = accuracy_score(y_test, model.predict(X_test))

artifact = {
    "model": model,
    "label_encoder": encoder,
    "features": feature_cols,
    "accuracy": float(accuracy)
}
joblib.dump(artifact, MODEL_DIR / "disease_model.joblib")

print(f"Model trained successfully. Test accuracy: {accuracy:.2%}")
print(f"Saved: {MODEL_DIR / 'disease_model.joblib'}")
